<?php
    $host = "localhost";
    $user = "root";
    $password = "apik12345";
    $database = "db_achb";
    $koneksi = mysqli_connect($host,$user,$password,$database);
?>